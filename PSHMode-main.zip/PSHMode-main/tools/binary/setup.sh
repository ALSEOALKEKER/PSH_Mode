mkdir bin &> /dev/null
g++ binary.cpp -o bin/binary
